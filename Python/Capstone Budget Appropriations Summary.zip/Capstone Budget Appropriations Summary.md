```python
import pandas as pd

# Define column headers based on your SQL query output
column_headers = [
    "budget_function_title", 
    "fr_entity_description", 
    "reporting_period_end", 
    "total_budgetary_resources_amount_cpe", 
    "gross_outlay_amount_by_tas_cpe", 
    "unobligated_balance_cpe", 
    "status_of_budgetary_resources_total_cpe", 
    "omnibus_flag"
]

# Load the CSV file with the specified headers
df = pd.read_csv("C:/Users/culex/OneDrive/Documents/CSU-Global/MIS581/Capstone Data/budget_appropriations_summary", header=None, names=column_headers)

# Display the first few rows to inspect
df.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>budget_function_title</th>
      <th>fr_entity_description</th>
      <th>reporting_period_end</th>
      <th>total_budgetary_resources_amount_cpe</th>
      <th>gross_outlay_amount_by_tas_cpe</th>
      <th>unobligated_balance_cpe</th>
      <th>status_of_budgetary_resources_total_cpe</th>
      <th>omnibus_flag</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Education, Training, Employment, and Social Se...</td>
      <td>Department of Education</td>
      <td>2017-03-31</td>
      <td>4.536645e+04</td>
      <td>79536473.35</td>
      <td>4.536645e+04</td>
      <td>4.536645e+04</td>
      <td>Non-Omnibus</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Energy</td>
      <td>Department of Energy</td>
      <td>2017-03-31</td>
      <td>1.981891e+08</td>
      <td>32026135.46</td>
      <td>1.725562e+08</td>
      <td>1.981891e+08</td>
      <td>Non-Omnibus</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Transportation</td>
      <td>Department of Transportation</td>
      <td>2017-03-31</td>
      <td>0.000000e+00</td>
      <td>0.00</td>
      <td>0.000000e+00</td>
      <td>0.000000e+00</td>
      <td>Non-Omnibus</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Energy</td>
      <td>Department of Energy</td>
      <td>2017-03-31</td>
      <td>1.762031e+07</td>
      <td>2931807.35</td>
      <td>1.762031e+07</td>
      <td>1.762031e+07</td>
      <td>Non-Omnibus</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Energy</td>
      <td>Department of Energy</td>
      <td>2017-03-31</td>
      <td>1.919562e+08</td>
      <td>2872.00</td>
      <td>1.919562e+08</td>
      <td>1.919562e+08</td>
      <td>Non-Omnibus</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Display summary information about the dataset
df.info()

# Show basic descriptive statistics for numeric columns
df.describe()

```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 489801 entries, 0 to 489800
    Data columns (total 8 columns):
     #   Column                                   Non-Null Count   Dtype  
    ---  ------                                   --------------   -----  
     0   budget_function_title                    489801 non-null  object 
     1   fr_entity_description                    489801 non-null  object 
     2   reporting_period_end                     489801 non-null  object 
     3   total_budgetary_resources_amount_cpe     489801 non-null  float64
     4   gross_outlay_amount_by_tas_cpe           489801 non-null  float64
     5   unobligated_balance_cpe                  489801 non-null  float64
     6   status_of_budgetary_resources_total_cpe  489801 non-null  float64
     7   omnibus_flag                             489801 non-null  object 
    dtypes: float64(4), object(4)
    memory usage: 29.9+ MB
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_budgetary_resources_amount_cpe</th>
      <th>gross_outlay_amount_by_tas_cpe</th>
      <th>unobligated_balance_cpe</th>
      <th>status_of_budgetary_resources_total_cpe</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>4.898010e+05</td>
      <td>4.898010e+05</td>
      <td>4.898010e+05</td>
      <td>4.898010e+05</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.357956e+09</td>
      <td>6.205638e+08</td>
      <td>7.080718e+08</td>
      <td>1.357956e+09</td>
    </tr>
    <tr>
      <th>std</th>
      <td>2.314102e+10</td>
      <td>1.258815e+10</td>
      <td>1.701584e+10</td>
      <td>2.314102e+10</td>
    </tr>
    <tr>
      <th>min</th>
      <td>-1.104312e+10</td>
      <td>-1.962001e+08</td>
      <td>-2.747932e+10</td>
      <td>-1.104312e+10</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.913274e+05</td>
      <td>0.000000e+00</td>
      <td>9.871196e+04</td>
      <td>1.913274e+05</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2.659186e+06</td>
      <td>6.256613e+05</td>
      <td>1.657284e+06</td>
      <td>2.659186e+06</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>3.629300e+07</td>
      <td>1.620394e+07</td>
      <td>2.128132e+07</td>
      <td>3.629300e+07</td>
    </tr>
    <tr>
      <th>max</th>
      <td>3.648563e+12</td>
      <td>1.192149e+12</td>
      <td>3.648563e+12</td>
      <td>3.648563e+12</td>
    </tr>
  </tbody>
</table>
</div>




```python
import matplotlib.pyplot as plt
import seaborn as sns

# Histograms for each budget-related field
budget_columns = [
    "total_budgetary_resources_amount_cpe", 
    "gross_outlay_amount_by_tas_cpe", 
    "unobligated_balance_cpe", 
    "status_of_budgetary_resources_total_cpe"
]

for column in budget_columns:
    plt.figure(figsize=(10, 6))
    sns.histplot(df[column], bins=50, kde=True)
    plt.title(f'Distribution of {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plt.show()

```


    
![png](output_2_0.png)
    



    
![png](output_2_1.png)
    



    
![png](output_2_2.png)
    



    
![png](output_2_3.png)
    



```python
# Group by omnibus_flag and calculate the mean for each budget metric
omnibus_summary = df.groupby('omnibus_flag')[budget_columns].mean()

# Plotting
omnibus_summary.plot(kind='bar', figsize=(12, 8), stacked=True)
plt.title("Average Budgetary Resources and Balances by Omnibus vs. Non-Omnibus Years")
plt.xlabel("Omnibus Flag")
plt.ylabel("Average Amount")
plt.legend(title="Budget Metric", bbox_to_anchor=(1.05, 1))
plt.show()

```


    
![png](output_3_0.png)
    



```python
# Convert reporting_period_end to datetime
df['reporting_period_end'] = pd.to_datetime(df['reporting_period_end'])

# Group data by year and omnibus flag
df['year'] = df['reporting_period_end'].dt.year
year_summary = df.groupby(['year', 'omnibus_flag'])[budget_columns].mean().unstack()

# Plot trends over time for each metric
for column in budget_columns:
    year_summary[column].plot(figsize=(14, 7))
    plt.title(f"Yearly Trend in {column} (Omnibus vs. Non-Omnibus)")
    plt.xlabel("Year")
    plt.ylabel(column)
    plt.legend(title="Omnibus Flag")
    plt.show()

```


    
![png](output_4_0.png)
    



    
![png](output_4_1.png)
    



    
![png](output_4_2.png)
    



    
![png](output_4_3.png)
    



```python
# Correlation matrix
correlation_matrix = df[budget_columns].corr()

# Heatmap for visualization
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
plt.title("Correlation Matrix of Budgetary Metrics")
plt.show()

```


    
![png](output_5_0.png)
    



```python
import scipy.stats as stats

# Separate the data by omnibus flag
omnibus_data = df[df['omnibus_flag'] == 'Omnibus']
non_omnibus_data = df[df['omnibus_flag'] == 'Non-Omnibus']

# T-Tests for each metric
t_test_total_budget = stats.ttest_ind(omnibus_data['total_budgetary_resources_amount_cpe'], non_omnibus_data['total_budgetary_resources_amount_cpe'])
t_test_gross_outlay = stats.ttest_ind(omnibus_data['gross_outlay_amount_by_tas_cpe'], non_omnibus_data['gross_outlay_amount_by_tas_cpe'])
t_test_unobligated_balance = stats.ttest_ind(omnibus_data['unobligated_balance_cpe'], non_omnibus_data['unobligated_balance_cpe'])
t_test_status_total = stats.ttest_ind(omnibus_data['status_of_budgetary_resources_total_cpe'], non_omnibus_data['status_of_budgetary_resources_total_cpe'])

# Mann-Whitney U Tests for each metric
mw_test_total_budget = stats.mannwhitneyu(omnibus_data['total_budgetary_resources_amount_cpe'], non_omnibus_data['total_budgetary_resources_amount_cpe'])
mw_test_gross_outlay = stats.mannwhitneyu(omnibus_data['gross_outlay_amount_by_tas_cpe'], non_omnibus_data['gross_outlay_amount_by_tas_cpe'])
mw_test_unobligated_balance = stats.mannwhitneyu(omnibus_data['unobligated_balance_cpe'], non_omnibus_data['unobligated_balance_cpe'])
mw_test_status_total = stats.mannwhitneyu(omnibus_data['status_of_budgetary_resources_total_cpe'], non_omnibus_data['status_of_budgetary_resources_total_cpe'])

# Print results
print("T-Test Results:")
print("Total Budgetary Resources:", t_test_total_budget)
print("Gross Outlay Amount:", t_test_gross_outlay)
print("Unobligated Balance:", t_test_unobligated_balance)
print("Status of Budgetary Resources:", t_test_status_total)

print("\nMann-Whitney U Test Results:")
print("Total Budgetary Resources:", mw_test_total_budget)
print("Gross Outlay Amount:", mw_test_gross_outlay)
print("Unobligated Balance:", mw_test_unobligated_balance)
print("Status of Budgetary Resources:", mw_test_status_total)

```

    T-Test Results:
    Total Budgetary Resources: TtestResult(statistic=0.15269863701659733, pvalue=0.8786359985623158, df=489799.0)
    Gross Outlay Amount: TtestResult(statistic=-0.45750203924274335, pvalue=0.6473104398101379, df=489799.0)
    Unobligated Balance: TtestResult(statistic=0.5227258233557861, pvalue=0.6011653016389348, df=489799.0)
    Status of Budgetary Resources: TtestResult(statistic=0.1526997619613621, pvalue=0.8786351113903774, df=489799.0)
    
    Mann-Whitney U Test Results:
    Total Budgetary Resources: MannwhitneyuResult(statistic=28733329632.0, pvalue=3.5442320631907937e-05)
    Gross Outlay Amount: MannwhitneyuResult(statistic=28218592935.0, pvalue=4.204088125226961e-11)
    Unobligated Balance: MannwhitneyuResult(statistic=28838119170.5, pvalue=2.7800346914141715e-10)
    Status of Budgetary Resources: MannwhitneyuResult(statistic=28733317972.0, pvalue=3.547962567231885e-05)
    


```python
# ANOVA and Kruskal-Wallis Tests
# ANOVA for Total Budgetary Resources by Year within Omnibus and Non-Omnibus categories
anova_total_budget_omnibus = stats.f_oneway(*(group['total_budgetary_resources_amount_cpe'] for name, group in omnibus_data.groupby(df['reporting_period_end'].dt.year)))
anova_total_budget_non_omnibus = stats.f_oneway(*(group['total_budgetary_resources_amount_cpe'] for name, group in non_omnibus_data.groupby(df['reporting_period_end'].dt.year)))

# Kruskal-Wallis Test for Total Budgetary Resources by Year within Omnibus and Non-Omnibus categories
kw_total_budget_omnibus = stats.kruskal(*(group['total_budgetary_resources_amount_cpe'] for name, group in omnibus_data.groupby(df['reporting_period_end'].dt.year)))
kw_total_budget_non_omnibus = stats.kruskal(*(group['total_budgetary_resources_amount_cpe'] for name, group in non_omnibus_data.groupby(df['reporting_period_end'].dt.year)))

# Print results
print("ANOVA Results by Year within Omnibus Flag:")
print("Omnibus Years:", anova_total_budget_omnibus)
print("Non-Omnibus Years:", anova_total_budget_non_omnibus)

print("\nKruskal-Wallis Results by Year within Omnibus Flag:")
print("Omnibus Years:", kw_total_budget_omnibus)
print("Non-Omnibus Years:", kw_total_budget_non_omnibus)

```

    ANOVA Results by Year within Omnibus Flag:
    Omnibus Years: F_onewayResult(statistic=2.7661973590459934, pvalue=0.04022926097813121)
    Non-Omnibus Years: F_onewayResult(statistic=6.236268560997476, pvalue=0.00031416905907063314)
    
    Kruskal-Wallis Results by Year within Omnibus Flag:
    Omnibus Years: KruskalResult(statistic=88.80872657881605, pvalue=3.948281583037417e-19)
    Non-Omnibus Years: KruskalResult(statistic=149.21594243146623, pvalue=3.8895492178074647e-32)
    


```python
# Selecting only numeric columns for correlation analysis
numeric_columns = ['total_budgetary_resources_amount_cpe', 
                   'gross_outlay_amount_by_tas_cpe', 
                   'unobligated_balance_cpe', 
                   'status_of_budgetary_resources_total_cpe']

# Pearson and Spearman correlations for Omnibus years (numeric columns only)
pearson_corr_omnibus = omnibus_data[numeric_columns].corr(method='pearson')
spearman_corr_omnibus = omnibus_data[numeric_columns].corr(method='spearman')

# Pearson and Spearman correlations for Non-Omnibus years (numeric columns only)
pearson_corr_non_omnibus = non_omnibus_data[numeric_columns].corr(method='pearson')
spearman_corr_non_omnibus = non_omnibus_data[numeric_columns].corr(method='spearman')

# Print results
print("Omnibus Year Correlations:")
print("Pearson:\n", pearson_corr_omnibus)
print("\nSpearman:\n", spearman_corr_omnibus)

print("\nNon-Omnibus Year Correlations:")
print("Pearson:\n", pearson_corr_non_omnibus)
print("\nSpearman:\n", spearman_corr_non_omnibus)

```

    Omnibus Year Correlations:
    Pearson:
                                              total_budgetary_resources_amount_cpe  \
    total_budgetary_resources_amount_cpe                                 1.000000   
    gross_outlay_amount_by_tas_cpe                                       0.672000   
    unobligated_balance_cpe                                              0.832159   
    status_of_budgetary_resources_total_cpe                              1.000000   
    
                                             gross_outlay_amount_by_tas_cpe  \
    total_budgetary_resources_amount_cpe                           0.672000   
    gross_outlay_amount_by_tas_cpe                                 1.000000   
    unobligated_balance_cpe                                        0.154161   
    status_of_budgetary_resources_total_cpe                        0.672000   
    
                                             unobligated_balance_cpe  \
    total_budgetary_resources_amount_cpe                    0.832159   
    gross_outlay_amount_by_tas_cpe                          0.154161   
    unobligated_balance_cpe                                 1.000000   
    status_of_budgetary_resources_total_cpe                 0.832159   
    
                                             status_of_budgetary_resources_total_cpe  
    total_budgetary_resources_amount_cpe                                    1.000000  
    gross_outlay_amount_by_tas_cpe                                          0.672000  
    unobligated_balance_cpe                                                 0.832159  
    status_of_budgetary_resources_total_cpe                                 1.000000  
    
    Spearman:
                                              total_budgetary_resources_amount_cpe  \
    total_budgetary_resources_amount_cpe                                 1.000000   
    gross_outlay_amount_by_tas_cpe                                       0.625066   
    unobligated_balance_cpe                                              0.919638   
    status_of_budgetary_resources_total_cpe                              1.000000   
    
                                             gross_outlay_amount_by_tas_cpe  \
    total_budgetary_resources_amount_cpe                           0.625066   
    gross_outlay_amount_by_tas_cpe                                 1.000000   
    unobligated_balance_cpe                                        0.518256   
    status_of_budgetary_resources_total_cpe                        0.625065   
    
                                             unobligated_balance_cpe  \
    total_budgetary_resources_amount_cpe                    0.919638   
    gross_outlay_amount_by_tas_cpe                          0.518256   
    unobligated_balance_cpe                                 1.000000   
    status_of_budgetary_resources_total_cpe                 0.919638   
    
                                             status_of_budgetary_resources_total_cpe  
    total_budgetary_resources_amount_cpe                                    1.000000  
    gross_outlay_amount_by_tas_cpe                                          0.625065  
    unobligated_balance_cpe                                                 0.919638  
    status_of_budgetary_resources_total_cpe                                 1.000000  
    
    Non-Omnibus Year Correlations:
    Pearson:
                                              total_budgetary_resources_amount_cpe  \
    total_budgetary_resources_amount_cpe                                 1.000000   
    gross_outlay_amount_by_tas_cpe                                       0.693305   
    unobligated_balance_cpe                                              0.829581   
    status_of_budgetary_resources_total_cpe                              1.000000   
    
                                             gross_outlay_amount_by_tas_cpe  \
    total_budgetary_resources_amount_cpe                           0.693305   
    gross_outlay_amount_by_tas_cpe                                 1.000000   
    unobligated_balance_cpe                                        0.181461   
    status_of_budgetary_resources_total_cpe                        0.693305   
    
                                             unobligated_balance_cpe  \
    total_budgetary_resources_amount_cpe                    0.829581   
    gross_outlay_amount_by_tas_cpe                          0.181461   
    unobligated_balance_cpe                                 1.000000   
    status_of_budgetary_resources_total_cpe                 0.829581   
    
                                             status_of_budgetary_resources_total_cpe  
    total_budgetary_resources_amount_cpe                                    1.000000  
    gross_outlay_amount_by_tas_cpe                                          0.693305  
    unobligated_balance_cpe                                                 0.829581  
    status_of_budgetary_resources_total_cpe                                 1.000000  
    
    Spearman:
                                              total_budgetary_resources_amount_cpe  \
    total_budgetary_resources_amount_cpe                                 1.000000   
    gross_outlay_amount_by_tas_cpe                                       0.640562   
    unobligated_balance_cpe                                              0.914241   
    status_of_budgetary_resources_total_cpe                              1.000000   
    
                                             gross_outlay_amount_by_tas_cpe  \
    total_budgetary_resources_amount_cpe                           0.640562   
    gross_outlay_amount_by_tas_cpe                                 1.000000   
    unobligated_balance_cpe                                        0.527175   
    status_of_budgetary_resources_total_cpe                        0.640562   
    
                                             unobligated_balance_cpe  \
    total_budgetary_resources_amount_cpe                    0.914241   
    gross_outlay_amount_by_tas_cpe                          0.527175   
    unobligated_balance_cpe                                 1.000000   
    status_of_budgetary_resources_total_cpe                 0.914241   
    
                                             status_of_budgetary_resources_total_cpe  
    total_budgetary_resources_amount_cpe                                    1.000000  
    gross_outlay_amount_by_tas_cpe                                          0.640562  
    unobligated_balance_cpe                                                 0.914241  
    status_of_budgetary_resources_total_cpe                                 1.000000  
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

# Box plot for total budgetary resources by omnibus flag
plt.figure(figsize=(10, 6))
sns.boxplot(x='omnibus_flag', y='total_budgetary_resources_amount_cpe', data=df)
plt.title("Total Budgetary Resources by Omnibus Flag")
plt.xlabel("Omnibus Flag")
plt.ylabel("Total Budgetary Resources Amount (CPE)")
plt.show()

```


    
![png](output_9_0.png)
    



```python
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Define the headers
column_headers = [
    "budget_function_title", 
    "fr_entity_description", 
    "reporting_period_end", 
    "total_budgetary_resources_amount_cpe", 
    "gross_outlay_amount_by_tas_cpe", 
    "unobligated_balance_cpe", 
    "status_of_budgetary_resources_total_cpe", 
    "omnibus_flag"
]

# Load the CSV file into a DataFrame with the specified headers
data = pd.read_csv("C:/Users/culex/OneDrive/Documents/CSU-Global/MIS581/Capstone Data/budget_appropriations_summary", header=None, names=column_headers)

# Convert 'omnibus_flag' to a categorical variable
data['omnibus_flag'] = data['omnibus_flag'].astype('category')

# 1. Boxplot for financial metrics by Omnibus vs Non-Omnibus Years
plt.figure(figsize=(12, 6))
sns.boxplot(x="omnibus_flag", y="total_budgetary_resources_amount_cpe", data=data)
plt.title("Total Budgetary Resources by Omnibus vs Non-Omnibus Years")
plt.xlabel("Omnibus Flag")
plt.ylabel("Total Budgetary Resources Amount (CPE)")
plt.show()

# Gross Outlay Amount
plt.figure(figsize=(12, 6))
sns.boxplot(x="omnibus_flag", y="gross_outlay_amount_by_tas_cpe", data=data)
plt.title("Gross Outlay Amount by Omnibus vs Non-Omnibus Years")
plt.xlabel("Omnibus Flag")
plt.ylabel("Gross Outlay Amount (CPE)")
plt.show()

# Unobligated Balance
plt.figure(figsize=(12, 6))
sns.boxplot(x="omnibus_flag", y="unobligated_balance_cpe", data=data)
plt.title("Unobligated Balance by Omnibus vs Non-Omnibus Years")
plt.xlabel("Omnibus Flag")
plt.ylabel("Unobligated Balance (CPE)")
plt.show()

# Status of Budgetary Resources Total
plt.figure(figsize=(12, 6))
sns.boxplot(x="omnibus_flag", y="status_of_budgetary_resources_total_cpe", data=data)
plt.title("Status of Budgetary Resources by Omnibus vs Non-Omnibus Years")
plt.xlabel("Omnibus Flag")
plt.ylabel("Status of Budgetary Resources Total (CPE)")
plt.show()

```


    
![png](output_10_0.png)
    



    
![png](output_10_1.png)
    



    
![png](output_10_2.png)
    



    
![png](output_10_3.png)
    



```python
# Convert reporting_period_end to datetime format
data['reporting_period_end'] = pd.to_datetime(data['reporting_period_end'])

# Line plot for Total Budgetary Resources over time
plt.figure(figsize=(14, 8))
sns.lineplot(x='reporting_period_end', y='total_budgetary_resources_amount_cpe', hue='omnibus_flag', data=data)
plt.title("Total Budgetary Resources Over Time by Omnibus Flag")
plt.xlabel("Reporting Period End")
plt.ylabel("Total Budgetary Resources Amount (CPE)")
plt.show()

```


    
![png](output_11_0.png)
    



```python
# Histogram for Total Budgetary Resources by Omnibus Flag
plt.figure(figsize=(12, 6))
sns.histplot(data, x='total_budgetary_resources_amount_cpe', hue='omnibus_flag', element='step', kde=True)
plt.title("Distribution of Total Budgetary Resources by Omnibus Flag")
plt.xlabel("Total Budgetary Resources Amount (CPE)")
plt.ylabel("Frequency")
plt.show()

```


    
![png](output_12_0.png)
    



```python
# Select only numeric columns for correlation
numeric_columns = data.select_dtypes(include=['float64', 'int64'])

# Filter data for Omnibus years and calculate correlations
omnibus_corr = numeric_columns[data['omnibus_flag'] == 'Omnibus'].corr()
plt.figure(figsize=(10, 8))
sns.heatmap(omnibus_corr, annot=True, cmap='coolwarm', fmt=".2f")
plt.title("Correlation Matrix of Financial Metrics in Omnibus Years")
plt.show()

# Filter data for Non-Omnibus years and calculate correlations
non_omnibus_corr = numeric_columns[data['omnibus_flag'] == 'Non-Omnibus'].corr()
plt.figure(figsize=(10, 8))
sns.heatmap(non_omnibus_corr, annot=True, cmap='coolwarm', fmt=".2f")
plt.title("Correlation Matrix of Financial Metrics in Non-Omnibus Years")
plt.show()

```


    
![png](output_13_0.png)
    



    
![png](output_13_1.png)
    



```python
# Group by budget_function_title and omnibus_flag
grouped_data = data.groupby(['budget_function_title', 'omnibus_flag'])['total_budgetary_resources_amount_cpe'].mean().reset_index()

# Bar plot
plt.figure(figsize=(14, 10))
sns.barplot(x='total_budgetary_resources_amount_cpe', y='budget_function_title', hue='omnibus_flag', data=grouped_data, dodge=True)
plt.title("Average Total Budgetary Resources by Budget Function and Omnibus Flag")
plt.xlabel("Average Total Budgetary Resources Amount (CPE)")
plt.ylabel("Budget Function Title")
plt.show()

```


    
![png](output_14_0.png)
    



```python
# Extract fiscal year from reporting_period_end
data['fiscal_year'] = data['reporting_period_end'].dt.year

# Boxplot for Total Budgetary Resources by Year and Omnibus Flag
plt.figure(figsize=(14, 8))
sns.boxplot(x='fiscal_year', y='total_budgetary_resources_amount_cpe', hue='omnibus_flag', data=data)
plt.title("Total Budgetary Resources by Fiscal Year and Omnibus Flag")
plt.xlabel("Fiscal Year")
plt.ylabel("Total Budgetary Resources Amount (CPE)")
plt.xticks(rotation=45)
plt.show()

```


    
![png](output_15_0.png)
    



```python

```
